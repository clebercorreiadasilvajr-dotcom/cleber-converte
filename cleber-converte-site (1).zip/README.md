# Cleber Converte — site

Site estático (sem build). Arquivos:

- `index.html` — o site completo
- `404.html` — página de erro (a Vercel usa automaticamente)
- `vercel.json` — configuração e cabeçalhos de segurança
- `robots.txt` — libera os buscadores

## Publicar com atualização automática (uma única vez)

1. Crie um repositório no GitHub (ex.: `cleber-converte`) e envie estes arquivos
   (botão "Add file → Upload files", ou pelo terminal:)
   ```
   git init && git add . && git commit -m "site"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/cleber-converte.git
   git push -u origin main
   ```
2. Em vercel.com: **Add New → Project → Import** o repositório.
   Deixe "Framework Preset: Other", sem build command e sem output directory. Clique em **Deploy**.
3. Pronto. A partir daqui, **todo envio (push/commit) na branch `main` publica sozinho** em ~30 segundos.
   Outras branches e pull requests ganham um link de pré-visualização.

## Como atualizar o site depois

Troque o `index.html` no GitHub (abra o arquivo → lápis → cole o novo código → *Commit changes*,
ou "Upload files" para substituir). A Vercel publica automaticamente.

## Alterações comuns (dentro do `index.html`)

- WhatsApp: constante `WA` (DDI+DDD+número, só dígitos).
- Logo oficial: constante `LOGO` (troque pelo `<img>` da logo).

## Domínio próprio

Vercel → projeto → **Settings → Domains → Add** e siga os registros DNS indicados.
